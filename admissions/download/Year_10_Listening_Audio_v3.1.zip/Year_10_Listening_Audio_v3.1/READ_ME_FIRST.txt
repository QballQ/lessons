Year 10 Admission Assessment, version 3.1: listening recordings

Use with Y10_Student_Paper_v3.1 and Y10_Assessor_Booklet_v3.1.

Y10_Listening_Part_A_v3.1.mp3   about 6.5 minutes
Y10_Listening_Part_B_v3.1.mp3   about 9.5 minutes
Y10_Listening_Full_v3.1.mp3     about 16 minutes (Part A then Part B)

Each track has the instructions, one minute to read the questions, the
talk played twice, and one minute to finish. Do not pause the recording.

Play Part A, then Part B. Use the separate tracks if you may need to stop
after Part A: a student who scores 2 or fewer in Part A may leave out
Part B (assessor booklet, stopping rules).

Play it on a speaker at a clear, comfortable volume in a quiet room, and
check the volume before the student arrives.

Voices: offline text-to-speech, British English. Mark the paper with the
v3.1 assessor booklet as usual.
