International Programme Admissions Pack, October 2026

Years 1 to 6: version 1.
Years 7 to 10: VERSION 2 (harder listening and reading; maths aimed at the
higher end, scored separately for fluency, word questions and applied
problems). Use the files and packs marked v2. The superseded version 1
packs are in Candidate_Packs/v1_superseded for reference only.

Start with 00_Admissions_Guide.pdf. Print one pack per candidate from
Candidate_Packs/ (double-sided). Print Reading_Cards_to_Laminate.pdf once
per room. 02_Listening_Evidence_Statement.pdf is for the admissions and
English teams.

The bands are provisional until the papers have been trialled (see the
guide, Section 10, and the listening evidence statement, Section 5).
