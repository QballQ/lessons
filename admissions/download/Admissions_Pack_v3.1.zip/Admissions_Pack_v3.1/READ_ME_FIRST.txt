International Programme Admissions Pack, VERSION 3.1, document set of 21 October 2026

START HERE: 1_Start_Here/04_Admissions_Team_Pack.pdf. It is the simple pack for the admissions team and
assessors: what to print, the timetable for each phase, the listening recordings, the handover to the interviewer,
filing and the rules on one page.

WHAT IS IN EACH FOLDER
  1_Start_Here                  The admissions team pack (8 pages). Print it once for the team.
  2_Print_For_Each_Candidate    One PDF for each year group: the student paper or booklet, the grading sheet, the
                                Reading front sheet, the Interview sheet, the parent conversation record and the final
                                mark sheet (Years 1 to 3 also have the Early Reading Screen record: print only the
                                sheets you expect to use). Print double-sided. Staff pages: about 14 for each candidate,
                                down from about 32.
  3_Print_Once                  One assessor folder for each year group (the assessor instructions, the interviewer guide,
                                the sentence reading guide and, in Years 1 to 3, the Early Reading Screen guide), and the
                                reading cards to laminate. No student name, nothing written on them: print once, reuse.
  4_Send_Before_The_Visit       The previous homeroom teacher reference (English and Chinese).
  5_Full_Guide_And_Evidence     The full guide for staff, the reading books list, the listening evidence statement and the
                                version register. Keep these as the evidence behind the pack.
  6_Single_Sheets               Every sheet as a separate PDF, for reprinting one sheet: the student papers, assessor
                                instructions and grading sheets by year group; the forms; the reading screens.

THE LISTENING RECORDINGS are in the separate downloads (Listening_Audio_Years_1_to_6, 7_to_8 and 9_to_10). The voice is
slower for younger students.

Every year group uses version 3.1 (see 5_Full_Guide_And_Evidence/03_Version_Register.pdf). The questions, mark schemes
and band guides are unchanged by the new document set. Mark a paper only with the instructions of the same version.
The bands are provisional until the papers have been trialled (guide, Section 10, and the listening evidence statement,
Section 5). The Chinese text in the homeroom teacher reference needs a native-speaker check before use.
