International Programme Admissions Pack, VERSION 3.1, October 2026

Every year group uses version 3.1. Every paper shows "v3.1" on the front
page and in the footer of every page.

Years 1 to 6: version 1 with clearer printed maths instructions after a
review by the mathematics department (Year 2 questions 11, 13, 17, 19 and
20; Year 4 question 11).
Years 7 to 10: version 2 with the third reading text (Part C) removed.
The reading paper is Parts A and B (16 marks) in the same 15 minutes.

Start with 00_Admissions_Guide.pdf. Print one pack per candidate from
Candidate_Packs/ (double-sided). Print Reading_Cards_to_Laminate.pdf once
per room. 03_Version_Register.pdf says what each version contains and has
a candidate log: record the version each student sat.
02_Listening_Evidence_Statement.pdf is for the admissions and English teams.

Mark a paper only with the booklet of the same version.
The bands are provisional until the papers have been trialled (see the
guide, Section 10, and the listening evidence statement, Section 5).
