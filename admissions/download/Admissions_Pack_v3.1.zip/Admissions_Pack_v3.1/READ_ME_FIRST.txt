International Programme Admissions Pack, VERSION 3.1 (document set of 21 October 2026; tracker added 27 October 2026)

TWO LEVELS: a simple pack to run the visit, and the detailed assessor pages behind it.

SIMPLE DEPLOYMENT (this is all most staff need)
  1. Read 1_START_HERE/04_Admissions_Team_Pack.pdf (8 pages): who does what, what to print, a timetable for each
     phase, the listening recordings, the handover to the interviewer, filing.
  2. Pin up the one-page day sheet for the phase: 1_START_HERE/Day_Sheet_Years_1_to_3, 4_to_6 or 7_to_10.
  3. Print the candidate pack for the year group from 2_PRINT_FOR_EACH_CANDIDATE, double-sided, one for each
     candidate. It holds the student paper, the grading sheet, the Reading front sheet, the Interview sheet, the
     parent conversation record, the final mark sheet and the assessment result and report (the one-sheet front
     cover that goes with the marked papers once the decision is confirmed).
  4. Copy the listening recording for the year group to a laptop or phone (separate downloads, with their own
     read-me).
  5. Enter each candidate in the tracker (7_ADMISSIONS_TRACKER): one sheet for each year group, and a Dashboard that
     shows stages, levels, decisions and support for all year groups. Start with the sheet How_To_Use; the DEMO copy
     has fictional candidates, to see it working.

THE DETAIL BEHIND IT (back-up for assessors and interviewers)
  3_PRINT_ONCE_ASSESSOR_FOLDERS   One folder for each year group, printed once and reused (no student name, nothing
                                  written on it): the full assessor instructions (scripts, answers, mark schemes, band
                                  guides, what to look for), the interviewer guide, the sentence reading guide and, in
                                  Years 1 to 3, the Early Reading Screen guide. Also the reading cards to laminate.
  5_FULL_GUIDE_AND_EVIDENCE       The full guide for staff, the reading books list, the listening evidence statement and
                                  the version register. Keep these as the evidence behind the pack.
  6_SINGLE_SHEETS                 Every sheet as a separate PDF, for reprinting one sheet.
  7_ADMISSIONS_TRACKER            The tracking workbook (Excel) and a DEMO copy with fictional candidates. Keep the real
                                  one in the secure admissions folder: it holds children's personal data.

OTHER
  4_SEND_BEFORE_THE_VISIT         The previous homeroom teacher reference (English and Chinese).

Every year group uses version 3.1 (5_FULL_GUIDE_AND_EVIDENCE/03_Version_Register.pdf). The questions, mark schemes
and band guides are unchanged by the new document set. Mark a paper only with the instructions of the same version.
The bands are provisional until the papers have been trialled (guide, Section 10, and the listening evidence
statement, Section 5). The Chinese text in the homeroom teacher reference needs a native-speaker check before use.
The listening voices are text to speech: listen to each recording before using it.
