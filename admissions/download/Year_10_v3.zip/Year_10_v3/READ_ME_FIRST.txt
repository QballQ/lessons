Year 10 admission assessment: VERSION 3, October 2026
Version 1 papers with the version 2 listening

Year_10_Candidate_Pack_v3.pdf
    Everything for one candidate, in order: student paper, assessor booklet,
    sentence reading record, interview record, parent conversation record,
    candidate summary. Print double-sided, one per candidate.

Y10_Student_Paper_v3.pdf
Y10_Assessor_Booklet_v3.pdf
    The same paper and booklet as separate files, for extra copies.

03_Version_Register.pdf
    Which version each year group uses, and a candidate log: record the
    version each student sat (v3 for this trial).

Reading_Cards_to_Laminate.pdf
    The cards students read from in the interview. Print once per room.

Listening: Part A (questions 1 to 8) and Part B (questions 9 to 16), 16 marks,
version 2 band guide. Reading, writing, maths and science: version 1, unchanged.
Use the v3 paper only with the v3 booklet.
