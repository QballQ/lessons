Year 7 Admission Assessment, version 3.1: listening recording

Use with Y07_Student_Paper_v3.1, Y07_Assessor_Instructions_v3.1 (Section 3, Listening) and Y07_Grading_Sheet_v3.1.

TRACKS
  Y07_Listening_Full_v3.1.mp3   15:02 minutes: Part A then Part B
  Y07_Listening_Part_A_v3.1.mp3   6:52 minutes: one part only
  Y07_Listening_Part_B_v3.1.mp3   8:08 minutes: one part only

PACE
  The younger the student, the slower the voice and the longer the pauses. In Year 7 the voice speaks at about 160 words a minute (not counting the pauses), with a pause after every sentence. Counting the pauses, one reading of the script goes at about 125 words a minute: a live reader can use this to check their own pace.

HOW TO USE
  1. Have the student paper open at the Listening pages and a pencil ready. Check the volume before the student
     arrives.
  2. Play the Full track (Part A, then Part B). Do not pause the recording. Each part gives one minute to read the
     questions, plays the script twice (10 seconds apart) and gives time to finish.
  3. Use Part A and Part B as separate tracks if you may need to stop after Part A (stopping rules in the
     instructions, Section 2): play Part A, mark it, then play Part B only if the rule allows.
  4. Where the speakers are two people they have different voices, so the recording does not say their names.

VOICES AND VOLUME
  The voices are offline text-to-speech, British English. Play the recording on a speaker at a clear, comfortable
  volume in a quiet room. Mark the paper with the version 3.1 instructions as usual.
